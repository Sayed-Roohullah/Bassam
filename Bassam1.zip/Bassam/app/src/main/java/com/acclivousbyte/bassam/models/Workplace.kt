package com.acclivousbyte.bassam.models

data class Workplace(
    val id: Int,
    val job_title: String,
    val location: String
)