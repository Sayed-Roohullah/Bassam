package com.acclivousbyte.bassam.view.fragments

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.acclivousbyte.bassam.R
import com.acclivousbyte.bassam.databinding.FragmentDetailBinding
import com.acclivousbyte.bassam.koinDI.viewModelModule
import com.acclivousbyte.bassam.models.Children
import com.acclivousbyte.bassam.models.DataX
import com.acclivousbyte.bassam.models.Sibling
import com.acclivousbyte.bassam.view.adapter.childAdapter
import com.acclivousbyte.bassam.view.adapter.siblingAdapter
import com.acclivousbyte.bassam.viewModel.AlbassamViewModel
import com.bumptech.glide.Glide
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.core.context.unloadKoinModules

class detailFragment : Fragment(R.layout.fragment_detail) {
    private val albassamViewModel: AlbassamViewModel by viewModel()
    private lateinit var binding: FragmentDetailBinding

    private lateinit var childadapter: childAdapter
    private lateinit var siblingadapter: siblingAdapter

     var phone = " "
     var email =  " "
     var socail =  " "

    var p_id = 0

    private lateinit var socailinfo: DataX
    private lateinit var childerns :  List<Children>
    private lateinit var siblings:  List<Sibling>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentDetailBinding.bind(view)

        setupData()
        setupObserver()

        loadKoinModules(viewModelModule)

        binding.backbtn?.setOnClickListener {
            findNavController().navigateUp()
//          findNavController().navigate(R.id.action_detailFragment_to_homeFragment)
          //  activity?.onBackPressed()

         }
        binding.socail.setOnClickListener {
            val bundle = Bundle()
            bundle.putString("twitter", socailinfo.twitter)
            bundle.putString("insta", socailinfo.instagram)
            bundle.putString("snap", socailinfo.snapchat)
            findNavController().navigate(
                R.id.action_detailFragment_to_socailProfileFragment,
                bundle
            )
        }
        binding.mail.setOnClickListener {
             val intent = Intent(Intent.ACTION_SENDTO,
                Uri.parse("mailto:${email}"))
            intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "subject")
            intent.putExtra(android.content.Intent.EXTRA_TEXT, "")
            startActivity(Intent.createChooser(intent, "Email"))
        }
        binding.phone.setOnClickListener {
            call()

        }

        binding.childern.setOnClickListener {
            binding.siblingview.visibility = View.GONE
            binding.childernview.visibility = View.VISIBLE
            binding.rootimage.setImageDrawable(ContextCompat.getDrawable(requireContext(),
                    R.drawable.default_image))
            val bundle = arguments
            binding.roottext.text = bundle?.getString("name", "")
            childadapter = childAdapter(requireContext(), childerns)
            binding.childRecycle.layoutManager = LinearLayoutManager(requireContext())
            binding.childRecycle.addItemDecoration(DividerItemDecoration(context, 0))

            binding.childRecycle.adapter = childadapter

        }
        binding.sibling.setOnClickListener {
            binding.childernview.visibility = View.GONE
            binding.siblingview.visibility = View.VISIBLE
            val bundle = arguments
            binding.rootsib.text = bundle?.getString("name", "")
            siblingadapter = siblingAdapter(requireContext(), siblings)
            binding.siblingRecycle.layoutManager = LinearLayoutManager(requireContext())
            binding.siblingRecycle.addItemDecoration(DividerItemDecoration(context, 0))

            binding.siblingRecycle.adapter = siblingadapter

        }


    }


    private fun setupData() {
        val bundle = arguments
        p_id = arguments!!.getInt("id",0)
        binding.nodeIdPass.text = bundle?.getString("nodeid", "")
        binding.passName.text = bundle?.getString("name", "")
        val fname = bundle?.getString("fname", "")
        val gfname = bundle?.getString("gfname", "")
        val ggfname = bundle?.getString("ggfname", "")
        binding.passGrndname.text = fname + " " + gfname + " " + ggfname


    }


    fun setupObserver() {

        albassamViewModel.getPersonDetail(p_id)
        albassamViewModel.personlivedata.observe(viewLifecycleOwner, Observer {

            childerns = it.Data.children
            siblings = it.Data.siblings


            binding.calender.text = it.Data.p_dob
            binding.desctext.text = it.Data.brief_description
            binding.location.text = it.Data.p_location
            binding.edu1.text = it.Data.p_education
            binding.city.text = it.Data.city
            binding.country.text = it.Data.country
            binding.job2.text = it.Data.p_workplace

            socailinfo = it.Data
            val profileImage = it.Data.profile_picture_square

            if (profileImage == "") {
                binding.passProfile.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.default_image
                    )
                )
            } else {
                Glide.with(this).load(profileImage).into(binding.passProfile)
            }
            phone = it.Data.contact
            email = it.Data.email
            socail = it.Data.p_socialnetworks

            if (email == "") {
                binding.mail.isClickable = false
                binding.mail.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.email_icon_gray
                    )
                )

            }
            if (phone=="") {
                binding.phone.isClickable = false
                binding.phone.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.phone_icon_gray
                    )
                )
            }
            if (socail == "") {
                binding.socail.isClickable = false
                binding.socail.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.socail_icon_gray
                    )
                )
            }

            if (it.Data.brief_description == "") {
                binding.description.visibility = View.GONE
            }

            if (it.Data.p_location == "Hidden") {
                binding.location.visibility = View.GONE
            }
            if (it.Data.p_dob == "Hidden") {
                binding.calender.visibility = View.GONE
                binding.calIcon.visibility = View.GONE

            }
            if (it.Data.p_education == "Hidden") {
                binding.education.visibility = View.GONE
            }

            if (it.Data.is_worthy == "No") {
                binding.worthyPass.visibility = View.GONE

            }


        })

    }


    fun call() {
        val callIntent = Intent(Intent.ACTION_DIAL)
        callIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        callIntent.data = Uri.parse("tel:" + phone)
        resultLauncher.launch(callIntent)
    }

var resultLauncher =
    registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
             val data: Intent? = result.data
        }
        if (result.resultCode == Activity.RESULT_CANCELED) {

        }


    }

    override fun onDestroy() {
        super.onDestroy()
        unloadKoinModules(viewModelModule)
    }



}