package com.acclivousbyte.bassam.models

data class DetialModel(
    val Data: List<Data>,
    val Exceptions: String,
    val Message: String,
    val ResultType: Int,
    val Status: Int
)