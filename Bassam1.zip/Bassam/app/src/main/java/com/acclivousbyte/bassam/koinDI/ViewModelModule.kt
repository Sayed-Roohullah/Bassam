package com.acclivousbyte.bassam.koinDI

import android.os.Build
import androidx.annotation.RequiresApi
import com.acclivousbyte.bassam.viewModel.AlbassamViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

@RequiresApi(Build.VERSION_CODES.M)
val viewModelModule = module {
    viewModel {
        AlbassamViewModel(get())
    }

}