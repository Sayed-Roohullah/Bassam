package com.acclivousbyte.bassam.models

data class Education(
    val id: Int,
    val institute: String,
    val level: String,
    val level_arabic: String,
    val program_title: String,
    val year: String
)