package com.acclivousbyte.bassam.backend

import android.app.Application
import com.acclivousbyte.bassam.koinDI.appModule
import com.acclivousbyte.bassam.koinDI.repoModule
import com.acclivousbyte.bassam.koinDI.viewModelModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@App)
            modules(listOf(appModule, repoModule, viewModelModule))
        }
    }
}