package com.acclivousbyte.bassam.models

data class PersonDetail(
    val Data: DataX,
    val Exceptions: String,
    val Message: String,
    val ResultType: Int,
    val Status: Int
)