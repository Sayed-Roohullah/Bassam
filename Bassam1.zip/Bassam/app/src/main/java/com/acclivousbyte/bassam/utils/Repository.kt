package com.acclivousbyte.bassam.utils
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.acclivousbyte.bassam.backend.ApiServices
import com.acclivousbyte.bassam.models.DetialModel
import com.acclivousbyte.bassam.models.PersonDetail
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class Repository(private val apiServices: ApiServices) {

    private val persondetail = MutableLiveData<PersonDetail>()
    val personData: LiveData<PersonDetail>
        get() = persondetail

    private val _detail = MutableLiveData<DetialModel>()
    val detailData: LiveData<DetialModel>
        get() = _detail

    val errorMessage = MutableLiveData<String>()
    val loading = MutableLiveData<Boolean>()

    fun getDetail() {
        errorMessage.postValue(  "No data found")
        loading.postValue(true)
        val result = apiServices.getDetail()
         result.enqueue(object : Callback<DetialModel> {
            override fun onResponse(
                call: Call<DetialModel>,
                response: Response<DetialModel>
            ) {
                val result = response.body()
                     if (result != null) {
                        _detail.postValue(response.body())
                         loading.postValue(false)
                    }
            }

            override fun onFailure(call: Call<DetialModel>, t: Throwable) {
                Log.e("e", t.toString())
                errorMessage.postValue(t.message)
                loading.postValue(false)

            }

        })
    }

    fun getPersonDetail(id : Int) {
        errorMessage.postValue(  "No data found")
        loading.postValue(true)
        val result = apiServices.getPesonDetail(id)
        result.enqueue(object : Callback<PersonDetail> {
            override fun onResponse(
                call: Call<PersonDetail>,
                response: Response<PersonDetail>
            ) {
                val result = response.body()
                 if (result != null) {
                    persondetail.postValue(response.body())
                     loading.postValue(false)
                }
            }

            override fun onFailure(call: Call<PersonDetail>, t: Throwable) {
                Log.e("e", t.toString())
                errorMessage.postValue(t.message)
                loading.postValue(false)
             }

        })
    }
}