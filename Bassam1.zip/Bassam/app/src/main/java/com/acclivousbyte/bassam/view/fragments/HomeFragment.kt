package com.acclivousbyte.bassam.view.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.acclivousbyte.bassam.R
import com.acclivousbyte.bassam.koinDI.viewModelModule
import com.acclivousbyte.bassam.models.Data
import com.acclivousbyte.bassam.utils.OnClickView
import com.acclivousbyte.bassam.view.adapter.parentAdapter
import com.acclivousbyte.bassam.viewModel.AlbassamViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.core.context.unloadKoinModules


class HomeFragment : Fragment(), OnClickView, View.OnClickListener {
    private val albassamViewModel: AlbassamViewModel by viewModel()
    private lateinit var adapter: parentAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var searchView: SearchView

    private lateinit var maleview: ImageView
    private lateinit var femaleview: ImageView
    private lateinit var worthyview: ImageView

    private lateinit var filterArray: ArrayList<Data>

    var isMale = true
    var isFemale = false
    var isWorthy = false


    var p_id = 0

    private var rootView: View? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_home, container, false)

            loadKoinModules(viewModelModule)

            initailizeView()

            setupObserver()



            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String): Boolean {
                    adapter.filter.filter(query)
                    return false
                }

                override fun onQueryTextChange(newText: String): Boolean {
                    adapter.filter.filter(newText)
                    return false
                }
            })
            val closeBtn: View = searchView.findViewById(androidx.appcompat.R.id.search_close_btn)
            closeBtn.setOnClickListener {
                searchView.setQuery("", false)
                searchView.isIconified = true
                setupObserver()
            }

            maleview.setOnClickListener(this)
            femaleview.setOnClickListener(this)
            worthyview.setOnClickListener(this)


        }
        return rootView

    }

    fun initailizeView() {
        maleview = rootView?.findViewById(R.id.malenew) as ImageView
        maleview.isActivated = true
        femaleview = rootView?.findViewById(R.id.femalenew) as ImageView
        worthyview = rootView?.findViewById(R.id.worthy) as ImageView

        filterArray = ArrayList()

        searchView = rootView?.findViewById(R.id.searchview) as SearchView
        recyclerView = rootView?.findViewById(R.id.parentrecycle) as RecyclerView


        adapter = parentAdapter(requireContext(), this)

    }


    private fun setupObserver() {
        val progressBar = view?.findViewById<ProgressBar>(R.id.progressbar)
        albassamViewModel.loadData.observe(viewLifecycleOwner, Observer {
            when (it) {
                true -> progressBar?.visibility = View.VISIBLE
                false -> progressBar?.visibility = View.GONE
            }
        })
        albassamViewModel.detailliveData.observe(viewLifecycleOwner, Observer {

            recyclerView.layoutManager = LinearLayoutManager(requireContext())
            recyclerView.addItemDecoration(
                DividerItemDecoration(
                    recyclerView.context,
                    (recyclerView.layoutManager as LinearLayoutManager).orientation
                )
            )
            if (adapter.getItemCount() == 0) {
                progressBar?.visibility = View.VISIBLE
            }
            progressBar?.visibility = View.GONE
            val data: Data
            data = it.Data.first()
            p_id = data.id
            albassamViewModel.getPersonDetail(p_id)
            recyclerView.adapter = adapter
            filterArray = arrayListOf()
            filterArray.addAll(it.Data)
            adapter.updatedList(filterArray)


        })
    }


    override fun onclicklistener(data: Data) {
        val bundle = Bundle()
        bundle.putString("name", data.name)
        bundle.putString("fname", data.father_name)
        bundle.putString("gfname", data.grand_father_name)
        bundle.putString("ggfname", data.g_grand_father_name)
        bundle.putString("nodeid", data.nodeID)
        bundle.putString("parentid", data.parent_id)
        bundle.putInt("id", data.id)
        p_id = data.id
        bundle.putString("image", data.profile_picture_square)
        bundle.putString("worth", data.is_worthy)

        findNavController().navigate(R.id.action_homeFragment_to_detailFragment, bundle)
    }


    override fun onClick(view: View?) {
        when (view?.getId()) {
            R.id.malenew -> {
                maleview.isActivated = !maleview.isActivated
                isMale = maleview.isActivated
                if (maleview.isActivated) {

                    listMerge(maleview.isActivated)
                } else {
                    listMerge(!maleview.isActivated)

                }

            }
            R.id.femalenew -> {
                femaleview.isActivated = !femaleview.isActivated
                isFemale = femaleview.isActivated

                if (femaleview.isActivated) {
                    listMerge(femaleview.isActivated)
                } else {
                    listMerge(!femaleview.isActivated)

                }
            }
            R.id.worthy -> {

                worthyview.isActivated = !worthyview.isActivated
                isWorthy = worthyview.isActivated

                if (worthyview.isActivated) {
                    listMerge(worthyview.isActivated)
                } else {
                    listMerge(!worthyview.isActivated)
                }

            }

            else -> alldata()
        }

    }

    fun alldata(){
        if (isFemale == false && isWorthy == false && isMale==false){
            adapter.updatedList(filterArray)
        }
    }

    fun listMerge(isSelect: Boolean) {
        val templist = ArrayList<Data>()
        if (isMale) {
            val filterList = filterArray.filter {
                it.gender.equals("0", ignoreCase = true)

            }
            templist.addAll(filterList)
        }

        if (isFemale) {
            val filterList = filterArray.filter {
                it.gender.equals("1", ignoreCase = true)

            }
            templist.addAll(filterList)
        }

        if (isWorthy) {
            val filterList = filterArray.filter {
                it.is_worthy.equals("Yes", ignoreCase = true)

            }
            templist.addAll(filterList)
        }

        adapter.updatedList(templist)

    }

    override fun onDestroy() {
        super.onDestroy()
        unloadKoinModules(viewModelModule)
    }
}