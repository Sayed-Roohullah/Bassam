package com.acclivousbyte.bassam.utils

import com.acclivousbyte.bassam.models.Data

interface OnClickView {
    fun onclicklistener(data: Data)
}