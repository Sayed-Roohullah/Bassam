package com.acclivousbyte.bassam.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.acclivousbyte.bassam.models.DetialModel
import com.acclivousbyte.bassam.models.PersonDetail
import com.acclivousbyte.bassam.utils.Repository
import kotlinx.coroutines.launch

class AlbassamViewModel(private val repository: Repository,
): ViewModel() {
    init {
        repository.getDetail()
     }

    val detailliveData: LiveData<DetialModel>
        get() = repository.detailData

    val loadData : LiveData<Boolean> get() = repository.loading


    val personlivedata: LiveData<PersonDetail>
    get() = repository.personData

    fun getPersonDetail(id:Int){
        viewModelScope.launch {
            repository.getPersonDetail(id)
        }
    }
}