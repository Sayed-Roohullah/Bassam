package com.acclivousbyte.bassam.backend

import com.acclivousbyte.bassam.models.DetialModel
import com.acclivousbyte.bassam.models.PersonDetail
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiServices {
    @GET("familymembers/v2")
      fun getDetail(): Call<DetialModel>

    @GET("familymembers/{id}")
      fun getPesonDetail(@Path("id") id: Int): Call<PersonDetail>

}